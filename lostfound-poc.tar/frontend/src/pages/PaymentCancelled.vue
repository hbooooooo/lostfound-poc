<template>
  <div class="container">
    <h2>Payment Cancelled</h2>
    <p>Your session was cancelled. You can close this window or try again.</p>
  </div>
</template>

<style scoped>
.container {
  max-width: 600px;
  margin: auto;
  padding: 2rem;
}
</style>