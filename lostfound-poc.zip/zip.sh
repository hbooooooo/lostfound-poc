zip -r lostfound-poc.zip . -x "*/node_modules/*" -x "*/uploads/*" -x "*/__pycache__/*" -x "*.pyc" -x "*.pyo" -x "*.DS_Store"
