<template>
  <div>
    <h1 class="text-xl font-bold">⚙️ Admin Panel</h1>
    <p class="text-gray-600">User access, moderation, system metrics (TBD).</p>
  </div>
</template>

<script>
export default {

}
</script>
