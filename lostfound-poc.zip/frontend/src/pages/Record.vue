<template>
  <div>
    <h1 class="text-xl font-bold mb-4">📄 Record New Item</h1>

    <input ref="fileInput" type="file" @change="handleFileChange" class="mb-2" />
    <button @click="uploadFile" :disabled="!selectedFile || loading" class="bg-blue-500 text-white px-4 py-2 rounded">
      {{ loading ? '⏳ Processing...' : 'Upload & OCR' }}
    </button>

    <div v-if="loading" class="mt-4">⏳ Processing OCR and Tagging...</div>

    <div v-else-if="ocrText || tags.length || embeddings.length || description" class="mt-4 space-y-4">
      <div v-if="description">
        <h2 class="font-semibold">📝 Description:</h2>
        <p class="bg-gray-100 p-2 rounded text-sm">
          {{ description }}
          <span class="text-gray-400 text-xs">({{ (descriptionScore * 100).toFixed(1) }}% confidence)</span>
        </p>
      </div>

      <div v-if="ocrText">
        <h2 class="font-semibold">🧠 Extracted Text:</h2>
        <pre class="bg-gray-100 p-2 rounded">{{ ocrText }}</pre>
      </div>

      <div v-if="tags.length">
        <h2 class="font-semibold">🏷️ Tags:</h2>
        <ul class="list-disc list-inside">
          <li v-for="(tag, idx) in tags" :key="idx">{{ tag }}</li>
        </ul>
      </div>

      <div v-if="embeddings.length">
        <h2 class="font-semibold">🧬 Embeddings (preview):</h2>
        <pre class="bg-gray-100 p-2 rounded">{{ embeddings.slice(0, 10).join(', ') }}...</pre>
      </div>
    </div>

    <!-- ➕ Metadata Form -->
    <div class="space-y-2 mt-4">
      <div>
        <label class="block text-sm font-medium">📍 Location (optional)</label>
        <input v-model="location" type="text" class="w-full border rounded p-2" placeholder="e.g. Terminal B, Gate 7" />
      </div>
      <div>
        <label class="block text-sm font-medium">🕒 Found At</label>
        <input v-model="foundAt" type="datetime-local" class="w-full border rounded p-2" />
      </div>
      <button @click="submitItem" class="bg-green-600 text-white px-4 py-2 rounded w-full">
        ✅ Save Item
      </button>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      selectedFile: null,
      ocrText: '',
      tags: [],
      embeddings: [],
      filename: '',
      description: '',
      descriptionScore: 0,
      location: '',
      foundAt: new Date().toISOString().slice(0, 16),
      loading: false
    }
  },
  mounted() {
    this.$emit('set-title', 'Record New Item')
  },
  methods: {
    handleFileChange(e) {
      this.selectedFile = e.target.files[0]
    },
    async uploadFile() {
      if (!this.selectedFile) return

      const formData = new FormData()
      formData.append('file', this.selectedFile)

      this.loading = true
      this.ocrText = ''
      this.tags = []
      this.embeddings = []
      this.filename = ''
      this.description = ''
      this.descriptionScore = 0

      try {
        const response = await axios.post('/api/ocr', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        })

        this.ocrText = response.data.text || ''
        this.tags = response.data.tags || []
        this.embeddings = response.data.embedding || []
        this.filename = response.data.filename || ''
        this.description = response.data.description || ''
        this.descriptionScore = response.data.description_score || 0
      } catch (error) {
        console.error('Upload or OCR failed:', error)
        this.ocrText = '[Error] Upload or OCR failed'
      } finally {
        this.loading = false
      }
    },
    async submitItem() {
      const token = localStorage.getItem('token')
      //console.log('[submitItem] token =', token)
      if (!token) {
        alert('You must be logged in to submit an item.')
        return
      }

      try {
        await axios.post('/api/items', {
          text: this.ocrText,
          tags: this.tags,
          embedding: this.embeddings,
          location: this.location,
          foundAt: this.foundAt,
          filename: this.filename,
          description: this.description,
          description_score: this.descriptionScore
        }, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
          }
        });

        alert('✅ Item saved!')

        this.selectedFile = null
        this.ocrText = ''
        this.tags = []
        this.embeddings = []
        this.filename = ''
        this.description = ''
        this.descriptionScore = 0
        this.location = ''
        this.foundAt = new Date().toISOString().slice(0, 16)

        this.$router.push('/')
      } catch (err) {
        console.error('Failed to save item:', err)
        alert('❌ Failed to save item')
      }
    }
  }
}
</script>
