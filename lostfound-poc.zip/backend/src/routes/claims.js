const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const db = require('../db'); // Assuming you have a db pool or client
const dayjs = require('dayjs');

// POST /api/claims/initiate
router.post('/initiate', async (req, res) => {
  const { item_id, email } = req.body;

  if (!item_id || !email) {
    return res.status(400).json({ error: 'Missing item_id or email' });
  }

  const token = crypto.randomUUID();
  const tokenExpires = dayjs().add(24, 'hour').toISOString(); // valid for 24h

  try {
    await db.query(
      `INSERT INTO claims (item_id, email, token, token_expires)
       VALUES ($1, $2, $3, $4)`,
      [item_id, email, token, tokenExpires]
    );

    const claimLink = `https://lost.bouard.com:5173/verify-claim?token=${token}`;

    // MOCK email send (replace with actual email service later)
    console.log(`[MAIL MOCK] Sent claim link to ${email}: ${claimLink}`);

    return res.status(200).json({ message: 'Claim link sent', link: claimLink });
  } catch (err) {
    console.error('Failed to create claim:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
